//
//  CalendarHeaderView.swift
//  CalendarControl
//
//  Created by Anoop M on 2018-12-14.
//  Copyright © 2018 anoop. All rights reserved.
//

import Foundation
import JTAppleCalendar

class CalendarSectionHeaderView: JTAppleCollectionReusableView {
    @IBOutlet var title: UILabel!
}
